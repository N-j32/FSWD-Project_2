                                             QUIENT TRAININGS 

Technologies Used:
1.Python 
2.Django 
3.HTML
4.CSS
5.Javascipt


Getting Started
These instructions will get know project and running on your local machine for development and testing purposes.

Get a virtual environment and pip up and running:

step_1: $ py -m venv venv
step_2: $ venv\Scripts\activate.bat
step_3: $ -m pip install Django
step_4: $ django-admin startproject appname
step_5: $ python manage.py makemigrations
step_6: $ python manage.py migrate
step_7: $ python manage.py runserver 

Above instructions are only to know project envirnoment used


Getting Started With Admin 
create a superuser
$ python manage.py createsuperuser

After this Username and Password should 
Username- Quient
Password- Quient123



1. Created a Contact model for contact form
2. Created a Viewdb.py  to handle all contact form
3. Gave a search option to search the name, email, phone
4. HTML starts from base.html


